# Made by sethiawsome | @seth_lol on discord (report bugs to me)
import pytesseract
from PIL import ImageGrab
import time

# your tesseract path here
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
left = 680
top = 218
right = 1208
bottom = 426

region = (left, top, right, bottom)  # (left, top, right, bottom)




rewards = []


last_detected_text = ""

try:
    while True:

        screenshot = ImageGrab.grab(bbox=region)
        

        text = pytesseract.image_to_string(screenshot).strip()
        
     
        if text and text != last_detected_text:
            rewards.append(text)
            print(f"Reward detected: {text}")
            last_detected_text = text

        # change depeding on how often u want to check for rewards
        time.sleep(1)  # Adjust if needed

except KeyboardInterrupt:

    with open('rewards_log.txt', 'a') as f:
        for reward in rewards:
            f.write(reward + '\n')
    print("Rewards saved to rewards_log.txt")
